
export interface HistoryItem {
  id: string;
  title: string;
  imageUrl: string;
  timestamp: number;
}

export interface ThumbnailData {
  title: string;
  headshot: string | null; // base64 string
  generatedImageUrl?: string;
}

export enum GenerationStatus {
  IDLE = 'IDLE',
  PROCESSING = 'PROCESSING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}
