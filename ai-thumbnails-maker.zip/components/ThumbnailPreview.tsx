
import React from 'react';
import { GenerationStatus } from '../types';

interface ThumbnailPreviewProps {
  status: GenerationStatus;
  imageUrl?: string;
  title: string;
}

export const ThumbnailPreview: React.FC<ThumbnailPreviewProps> = ({ status, imageUrl, title }) => {
  const isIdle = status === GenerationStatus.IDLE;
  const isProcessing = status === GenerationStatus.PROCESSING;
  const isSuccess = status === GenerationStatus.SUCCESS;

  const handleDownload = () => {
    if (!imageUrl) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `youtube-thumbnail-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="relative w-full aspect-video bg-slate-900 rounded-2xl border-2 border-slate-800 overflow-hidden shadow-2xl flex items-center justify-center">
        {isIdle && (
          <div className="flex flex-col items-center gap-4 text-slate-600 p-8 text-center">
            <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-xl font-medium">Your masterpiece will appear here</p>
            <p className="text-sm max-w-xs">Fill in the details on the left and hit generate to see the magic happen.</p>
          </div>
        )}

        {isProcessing && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center gap-6 z-10">
            <div className="relative w-20 h-20">
              <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-t-indigo-500 rounded-full animate-spin"></div>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold mb-2">Designing your thumbnail...</h3>
              <p className="text-slate-400 animate-pulse text-sm">
                Adding cinematic lighting & high-impact text
              </p>
            </div>
          </div>
        )}

        {isSuccess && imageUrl && (
          <img 
            src={imageUrl} 
            alt="Generated Thumbnail" 
            className="w-full h-full object-cover animate-in fade-in zoom-in duration-500"
          />
        )}
      </div>

      {isSuccess && imageUrl && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl">
          <div className="flex flex-col gap-1">
            <span className="text-sm text-indigo-300 font-semibold uppercase tracking-wider">Status</span>
            <span className="text-white font-medium flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Optimization Complete
            </span>
          </div>
          <button 
            onClick={handleDownload}
            className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download Thumbnail
          </button>
        </div>
      )}
    </div>
  );
};
