
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="w-full py-8 border-b border-slate-900 bg-slate-950/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 flex flex-col items-center text-center">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-2">
          AI <span className="gradient-text">Thumbnail</span> Maker
        </h1>
        <p className="text-slate-400 max-w-lg">
          Generate professional, high-CTR YouTube thumbnails using AI. 
          Upload your face, enter your title, and let Gemini do the rest.
        </p>
      </div>
    </header>
  );
};
