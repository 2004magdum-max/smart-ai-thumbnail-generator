
import React, { ChangeEvent } from 'react';
import { GenerationStatus, ThumbnailData } from '../types';

interface ControlPanelProps {
  data: ThumbnailData;
  setData: React.Dispatch<React.SetStateAction<ThumbnailData>>;
  onGenerate: () => void;
  onReset: () => void;
  status: GenerationStatus;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({ 
  data, 
  setData, 
  onGenerate, 
  onReset,
  status 
}) => {
  const handleTitleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setData(prev => ({ ...prev, title: e.target.value }));
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setData(prev => ({ ...prev, headshot: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const isIdle = status === GenerationStatus.IDLE || status === GenerationStatus.ERROR || status === GenerationStatus.SUCCESS;
  const isProcessing = status === GenerationStatus.PROCESSING;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <label className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Video Title</label>
        <input 
          type="text" 
          value={data.title}
          onChange={handleTitleChange}
          placeholder="e.g. How I made $10,000 in 30 days"
          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Your Headshot</label>
        <div className="relative group">
          <input 
            type="file" 
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
            id="headshot-upload"
          />
          <label 
            htmlFor="headshot-upload"
            className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-xl cursor-pointer transition-all duration-200 ${
              data.headshot 
                ? 'border-indigo-500/50 bg-indigo-500/5' 
                : 'border-slate-700 bg-slate-800/50 hover:bg-slate-800 hover:border-slate-600'
            }`}
          >
            {data.headshot ? (
              <div className="relative w-full h-full p-2">
                <img 
                  src={data.headshot} 
                  alt="Headshot preview" 
                  className="w-full h-full object-contain rounded-lg"
                />
                <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-lg">
                  <span className="text-sm font-medium">Change Photo</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-400">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <span className="text-sm">Click to upload photo</span>
              </div>
            )}
          </label>
        </div>
      </div>

      <div className="flex flex-col gap-3 mt-4">
        <button 
          onClick={onGenerate}
          disabled={!isIdle || isProcessing}
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all transform active:scale-[0.98] ${
            isProcessing 
              ? 'bg-slate-700 cursor-not-allowed text-slate-400' 
              : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-lg shadow-indigo-500/20 text-white'
          }`}
        >
          {isProcessing ? (
            <div className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </div>
          ) : 'Generate Thumbnail'}
        </button>

        {status === GenerationStatus.SUCCESS && (
          <button 
            onClick={onReset}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl font-semibold text-slate-300 transition-all"
          >
            Create Another
          </button>
        )}
      </div>
    </div>
  );
};
