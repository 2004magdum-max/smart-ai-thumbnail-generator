
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ThumbnailPreview } from './components/ThumbnailPreview';
import { ControlPanel } from './components/ControlPanel';
import { HistoryPanel } from './components/HistoryPanel';
import { generateThumbnail } from './services/geminiService';
import { GenerationStatus, ThumbnailData, HistoryItem } from './types';

const App: React.FC = () => {
  const [data, setData] = useState<ThumbnailData>({
    title: '',
    headshot: null,
  });
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [status, setStatus] = useState<GenerationStatus>(GenerationStatus.IDLE);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('thumbnail_history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('thumbnail_history', JSON.stringify(history));
  }, [history]);

  const handleGenerate = async () => {
    if (!data.title) {
      setErrorMessage('Please enter a video title.');
      return;
    }
    if (!data.headshot) {
      setErrorMessage('Please upload a headshot photo.');
      return;
    }

    setStatus(GenerationStatus.PROCESSING);
    setErrorMessage(null);

    try {
      const resultUrl = await generateThumbnail(data.title, data.headshot);
      
      const newHistoryItem: HistoryItem = {
        id: crypto.randomUUID(),
        title: data.title,
        imageUrl: resultUrl,
        timestamp: Date.now(),
      };

      setData(prev => ({ ...prev, generatedImageUrl: resultUrl }));
      setHistory(prev => [newHistoryItem, ...prev]);
      setStatus(GenerationStatus.SUCCESS);
    } catch (err: any) {
      console.error(err);
      setStatus(GenerationStatus.ERROR);
      setErrorMessage(err.message || 'An unexpected error occurred. Please try again.');
    }
  };

  const handleReset = () => {
    setData({ title: '', headshot: null });
    setStatus(GenerationStatus.IDLE);
    setErrorMessage(null);
  };

  const handleDeleteHistoryItem = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear all history?")) {
      setHistory([]);
    }
  };

  const handleSelectHistoryItem = (item: HistoryItem) => {
    setData({
      title: item.title,
      headshot: data.headshot, // Keep current headshot if any
      generatedImageUrl: item.imageUrl
    });
    setStatus(GenerationStatus.SUCCESS);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-slate-950 text-slate-50 selection:bg-indigo-500/30 pb-20">
      <Header />

      <main className="w-full max-w-6xl px-4 py-8 md:py-12 flex flex-col lg:flex-row gap-8 items-start">
        {/* Left Side: Controls */}
        <div className="w-full lg:w-1/3 flex flex-col gap-6 sticky top-24 z-40">
          <ControlPanel 
            data={data} 
            setData={setData} 
            onGenerate={handleGenerate} 
            status={status}
            onReset={handleReset}
          />
          
          {errorMessage && (
            <div className="p-4 bg-red-900/30 border border-red-500/50 rounded-xl text-red-200 text-sm animate-pulse">
              {errorMessage}
            </div>
          )}
        </div>

        {/* Right Side: Preview & History */}
        <div className="w-full lg:w-2/3 flex flex-col gap-12">
          <ThumbnailPreview 
            status={status} 
            imageUrl={data.generatedImageUrl} 
            title={data.title}
          />

          <HistoryPanel 
            history={history} 
            onSelectItem={handleSelectHistoryItem}
            onDeleteItem={handleDeleteHistoryItem}
            onClearAll={handleClearHistory}
          />
        </div>
      </main>

      <footer className="mt-auto py-8 text-slate-500 text-sm border-t border-slate-900 w-full text-center">
        Powered by Gemini 2.5 Flash • Built for Creators
      </footer>
    </div>
  );
};

export default App;
